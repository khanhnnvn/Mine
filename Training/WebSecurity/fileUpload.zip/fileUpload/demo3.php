<!doctype html>
<html lang="us">
<head>
	<link rel="stylesheet" href="./css/bootstrap.min.css">
	<link rel="stylesheet" href="./css/bootstrap-theme.min.css">
	<script src="./js/jquery.js"></script>
	<script src="./js/bootstrap.min.js"></script>
	<link rel="stylesheet" href="./css/bootstrap-theme.min.css">
	<script src="./js/jquery.js"></script>
	<script src="./js/bootstrap.min.js"></script>
</head>
<body>
	<div class="container">
	<h2>Images Upload Form</h2>
		<form enctype="multipart/form-data" action="#" method="post" name="upload">
			<div class="form-group" name="from_group">
				<label for="exampleInputFile">File input</label>
				<input type="file" id="exampleInputFile" name="uploaded_file">
				<p class="help-block">File upload example</p>
			</div>
			<input type="submit" class="btn btn-default" value="Upload" />

<?php
//Сheck that we have a file
session_start();
$session_id = session_id();
if((!empty($_FILES["uploaded_file"])) && ($_FILES['uploaded_file']['error'] == 0))
{
	$name = $_FILES['uploaded_file']['name'];
	# Check mime
	if($_FILES['uploaded_file']['type'] === "image/jpeg")
	{
		if(move_uploaded_file($_FILES['uploaded_file']['tmp_name'], "./tmp/".$name))
		{
			echo "<p class=\"text-success\">Upload to <a href=\"./tmp/$name\">$name</a> success!</p>";
		}
		else
		{
			echo "<p class=\"text-danger\">File uploading failed!</p>";
		}
	}
	else
	{
		echo "<p class=\"text-warning\">File invalid!</p>";
	}

}
?>
		</form> 
	</div>
</body> 
</html>
