<?php
	// Demo for upload zip with symlink
?>
<html> 
<body>
	<h2>Images Upload Form</h2>
	<form enctype="multipart/form-data" action="#" method="post">
		<input type="hidden" name="MAX_FILE_SIZE" value="1000000" />
		Choose a file to upload: <input name="uploaded_file" type="file" />
		<input type="submit" value="Upload" />
	</form> 
</body> 
<?php
//Сheck that we have a file
session_start();
$session_id = session_id();
if((!empty($_FILES["uploaded_file"])) && ($_FILES['uploaded_file']['error'] == 0))
{
	$filename = basename($_FILES['uploaded_file']['name']);
	$ext = strtolower(substr($filename, strrpos($filename, '.') + 1));
	$temp_path = "/tmp/".$session_id;
	if($_FILES["uploaded_file"]["size"] < 350000)
	{
		if (($ext == "jpg") || ($ext == "png") || ($ext == "zip"))
		{
			if($ext == "zip")
			{
				mkdir($temp_path, 0700);
				//*Zip process
				exec("unzip ".$_FILES['uploaded_file']['tmp_name']." -d ".$temp_path);

				$files = scandir($temp_path);
				for($x=2;$x<sizeof($files);$x++)
				{
					$data = file_get_contents($temp_path."/".$files[$x]);
					$type = $_FILES["uploaded_file"]["type"];
					$base64 = 'data:image/' . $type . ';base64,' . base64_encode($data);
					echo '<img src="'.$base64.'">';
					echo "<br>";
				}
				system("rm -rf ".$temp_path);

			}
			else
			{
				//Images process
				if(($_FILES["uploaded_file"]["type"] =="image/png") || ($_FILES["uploaded_file"]["type"] =="image/jpeg"))
				{
					$tmp_name = $_FILES['uploaded_file']['tmp_name'];
					$type = $_FILES["uploaded_file"]["type"];
					$data = file_get_contents($tmp_name);
					$base64 = 'data:image/' . $type . ';base64,' . base64_encode($data);
					echo '<img src="'.$base64.'">';
				}
				else
				{
					echo "Error: Only .jpg, .png images or .zip file are accepted for upload";
				}
			}
		}
		else
		{
			echo "Error: Only .jpg, .png images or .zip file are accepted for upload";
		}
	}
	else
	{
		echo "Error: Only file under 350Kb are accepted for upload";
	}
}
$flag = "CHANGE_FLAG_HERE";
?>
</html>
